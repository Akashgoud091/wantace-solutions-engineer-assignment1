WANTACE SOLUTIONS SPRINT — STARTER PACK

Files:
- Wantace_Submission_Draft.docx: draft for Parts A–E; includes a first-cut Part B, Part C and Part D.
- Part_A_Audit_Worksheet.docx: worksheet for the required real business audit.

Important:
1. Part A must be based on a real manufacturing/processing/repair business and a 20+ minute owner/manager conversation. Add genuine quotes and permission-approved photos.
2. Replace the LinkedIn placeholder with a real anonymised insight from Part A.
3. Vardhan analysis is based only on the supplied assignment pack. Validate assumptions with Ramesh/client before finalising.
4. Do not invent business details, quotes, photos, video links, AI errors or results.
5. Export the completed combined document to PDF/Google Docs, record the 5-minute video, and reply to the original assignment email with document link, video link, AI note and business name/area/owner phone in the email body (with permission).
